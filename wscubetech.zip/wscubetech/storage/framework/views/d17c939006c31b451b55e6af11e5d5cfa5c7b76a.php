<!DOCTYPE html>
<html lang="en">
<head>
    <title><?php echo e($data['title']); ?></title>
</head>
<body>

    <h3><?php echo e($data['body']); ?></h3>
    <br>
    <p>Thank You!</p>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\react laravel\wscubetech\resources\views/mailVerification.blade.php ENDPATH**/ ?>