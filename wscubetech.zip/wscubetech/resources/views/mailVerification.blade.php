<!DOCTYPE html>
<html lang="en">
<head>
    <title>{{$data['title']}}</title>
</head>
<body>

    <h3>{{ $data['body'] }}</h3>
    <br>
    <p>Thank You!</p>

</body>
</html>
